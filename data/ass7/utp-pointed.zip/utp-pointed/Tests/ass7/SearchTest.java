package ass7;

import org.junit.Assert;
import org.junit.Test;

import java.io.File;
import java.nio.file.Path;
import java.util.List;
import java.util.zip.ZipFile;

public class SearchTest {

    private static final InDirectorySearch IN_DIRECTORY_SEARCH = new InDirectorySearch();
    private static final InZipSearch IN_ZIP_SEARCH = new InZipSearch();
    private static final InJarSearch IN_JAR_SEARCH = new InJarSearch();

    private static final Path DIRECTORY = Path.of("D:/Projects/utp-pointed");
    private static final ZipFile ZIP = new ZipFile();


    private static final String NAME_1 = "src";
    private static final String PATH_1 = "D:\\Projects\\utp-pointed\\src";

    private static final String NAME_2 = "Main.java";
    private static final String PATH_2_1 = "D:\\Projects\\utp-pointed\\src\\ass4\\Main.java";
    private static final String PATH_2_2 = "D:\\Projects\\utp-pointed\\src\\ass5\\Main.java";

    @Test
    public void findByNameInDirectory() {
        System.out.println("findByNameInDirectory():");

        List<File> entries = IN_DIRECTORY_SEARCH.findByName(DIRECTORY, NAME_1);
        Assert.assertEquals(1, entries.size());
        Assert.assertEquals(NAME_1, entries.get(0).getName());
        Assert.assertEquals(PATH_1, entries.get(0).getPath());
        System.out.println(entries);

        entries = IN_DIRECTORY_SEARCH.findByName(DIRECTORY, NAME_2);
        Assert.assertEquals(2, entries.size());
        Assert.assertEquals(NAME_2, entries.get(0).getName());
        Assert.assertEquals(NAME_2, entries.get(1).getName());
        Assert.assertEquals(PATH_2_1, entries.get(0).getPath());
        Assert.assertEquals(PATH_2_2, entries.get(1).getPath());
        System.out.println(entries + "\n");
    }

    @Test
    public void findByContentInDirectory() {

    }

    @Test
    public void findByNameInZip() {

    }

    @Test
    public void findByContentInZip() {

    }

    @Test
    public void findByNameInJar() {

    }

    @Test
    public void findByContentInJar() {

    }


}
