package ass6.groups;

import ass6.people.Student;

import java.util.Collection;

public class StudentsGroup extends PeopleGroup<Student> {

    public StudentsGroup(String name, Collection<Student> students) {
        super(name, students);
    }

    public StudentsGroup(String name) {
        super(name);
    }

}
