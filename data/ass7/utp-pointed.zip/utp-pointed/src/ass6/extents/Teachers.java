package ass6.extents;

import ass6.people.Teacher;

import java.util.Collection;

public class Teachers extends PeopleExtents<Teacher> {

    public Teachers(Collection<Teacher> people) {
        super(people);
    }

    public Teachers() {
    }

}
