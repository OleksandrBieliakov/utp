package ass6.extents;

import ass6.groups.Subject;

import java.util.Collection;

public class Subjects extends GroupsExtents<Subject> {

    public Subjects(Collection<Subject> groups) {
        super(groups);
    }

    public Subjects() {
    }

}
