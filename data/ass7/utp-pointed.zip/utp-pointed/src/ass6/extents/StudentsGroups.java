package ass6.extents;

import ass6.groups.StudentsGroup;

import java.util.Collection;

public class StudentsGroups extends GroupsExtents<StudentsGroup> {

    public StudentsGroups(Collection<StudentsGroup> groups) {
        super(groups);
    }

    public StudentsGroups() {
    }

}
