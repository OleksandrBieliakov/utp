package ass6.extents;

import ass6.groups.Department;

import java.util.Collection;

public class Departments extends GroupsExtents<Department> {

    public Departments(Collection<Department> groups) {
        super(groups);
    }

    public Departments() {
    }

}
